/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 beginning beginning.jpg 
 * Time-stamp: Sunday 04/02/2023, 01:20:46
 * 
 * Image Information
 * -----------------
 * beginning.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BEGINNING_H
#define BEGINNING_H

extern const unsigned short beginning[38400];
#define BEGINNING_SIZE 76800
#define BEGINNING_LENGTH 38400
#define BEGINNING_WIDTH 240
#define BEGINNING_HEIGHT 160

#endif

