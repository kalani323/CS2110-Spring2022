/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize 240x160 blacksquare blacksquare.png 
 * Time-stamp: Monday 04/04/2022, 04:14:06
 * 
 * Image Information
 * -----------------
 * blacksquare.png 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BLACKSQUARE_H
#define BLACKSQUARE_H

extern const unsigned short blacksquare[38400];
#define BLACKSQUARE_SIZE 76800
#define BLACKSQUARE_LENGTH 38400
#define BLACKSQUARE_WIDTH 240
#define BLACKSQUARE_HEIGHT 160

#endif

