/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 rapunzel2 rapunzel2.webp 
 * Time-stamp: Sunday 04/02/2023, 00:52:51
 * 
 * Image Information
 * -----------------
 * rapunzel2.webp 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RAPUNZEL2_H
#define RAPUNZEL2_H

extern const unsigned short rapunzel2[1850];
#define RAPUNZEL2_SIZE 3700
#define RAPUNZEL2_LENGTH 1850
#define RAPUNZEL2_WIDTH 50
#define RAPUNZEL2_HEIGHT 37

#endif

