/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 pan pan.jpg 
 * Time-stamp: Sunday 04/02/2023, 01:22:20
 * 
 * Image Information
 * -----------------
 * pan.jpg 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PAN_H
#define PAN_H

extern const unsigned short pan[400];
#define PAN_SIZE 800
#define PAN_LENGTH 400
#define PAN_WIDTH 20
#define PAN_HEIGHT 20

#endif

