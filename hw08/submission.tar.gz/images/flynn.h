/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=50x37 flynn flynn.jpg 
 * Time-stamp: Saturday 04/01/2023, 23:16:34
 * 
 * Image Information
 * -----------------
 * flynn.jpg 50@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FLYNN_H
#define FLYNN_H

extern const unsigned short flynn[1850];
#define FLYNN_SIZE 3700
#define FLYNN_LENGTH 1850
#define FLYNN_WIDTH 50
#define FLYNN_HEIGHT 37

#endif

