/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 scarymen scarymen.jpg 
 * Time-stamp: Sunday 04/02/2023, 01:24:25
 * 
 * Image Information
 * -----------------
 * scarymen.jpg 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef SCARYMEN_H
#define SCARYMEN_H

extern const unsigned short scarymen[400];
#define SCARYMEN_SIZE 800
#define SCARYMEN_LENGTH 400
#define SCARYMEN_WIDTH 20
#define SCARYMEN_HEIGHT 20

#endif

