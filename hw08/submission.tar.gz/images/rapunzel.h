/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=15x15 rapunzel rapunzel.webp 
 * Time-stamp: Sunday 04/02/2023, 01:34:12
 * 
 * Image Information
 * -----------------
 * rapunzel.webp 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef RAPUNZEL_H
#define RAPUNZEL_H

extern const unsigned short rapunzel[225];
#define RAPUNZEL_SIZE 450
#define RAPUNZEL_LENGTH 225
#define RAPUNZEL_WIDTH 15
#define RAPUNZEL_HEIGHT 15

#endif

