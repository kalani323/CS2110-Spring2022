/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=20x20 mother mother.jpg 
 * Time-stamp: Sunday 04/02/2023, 01:24:10
 * 
 * Image Information
 * -----------------
 * mother.jpg 20@20
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MOTHER_H
#define MOTHER_H

extern const unsigned short mother[400];
#define MOTHER_SIZE 800
#define MOTHER_LENGTH 400
#define MOTHER_WIDTH 20
#define MOTHER_HEIGHT 20

#endif

