/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=240x160 beginner beginning.jpg 
 * Time-stamp: Sunday 04/02/2023, 01:01:10
 * 
 * Image Information
 * -----------------
 * beginning.jpg 240@160
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef BEGINNER_H
#define BEGINNER_H

extern const unsigned short beginning[38400];
#define BEGINNING_SIZE 76800
#define BEGINNING_LENGTH 38400
#define BEGINNING_WIDTH 240
#define BEGINNING_HEIGHT 160

#endif

