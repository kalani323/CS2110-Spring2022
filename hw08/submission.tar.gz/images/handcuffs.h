/*
 * Exported with nin10kit v1.8
 * Invocation command was nin10kit --mode=3 --resize=80x80 handcuffs handcuffs.jpg 
 * Time-stamp: Sunday 04/02/2023, 01:41:18
 * 
 * Image Information
 * -----------------
 * handcuffs.jpg 80@80
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef HANDCUFFS_H
#define HANDCUFFS_H

extern const unsigned short handcuffs[6400];
#define HANDCUFFS_SIZE 12800
#define HANDCUFFS_LENGTH 6400
#define HANDCUFFS_WIDTH 80
#define HANDCUFFS_HEIGHT 80

#endif

