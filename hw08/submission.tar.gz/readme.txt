Rapunzel's Journey
Kalani Dissanayake

-------------------------------------------
Help Rapunzel make it to her true love, Flynn. Avoid all the obstacles, like the evil "mother", the frying pan, and the scary men sent to find (AND KILL) you and Flynn.
-------------------------------------------
TO PLAY THE GAME:

-> click [enter] to start
-> once you leave the beginning screen, click [backspace] to go back to beginning screen
-> use the up/down/left/right keys to navigate, avoiding the obstacles (mother, frying pan, and scary men)
	-> make it to Flynn to win the game and reach your happy ending
	-> if you touch one of the obstacles, you lose!

NOTE: LOWER POINTS ARE BETTER BECAUSE THAT MEANS YOU WON QUICKER!!
-------------------------------------------
TO RUN FILE:

-> open docker
	-> navigate folder where cs2110 docker is
	-> run "./cs2110docker.sh" on local terminal
	-> go to link
-> navigate to hw08 folder on docker terminal
-> run "make mgba" 